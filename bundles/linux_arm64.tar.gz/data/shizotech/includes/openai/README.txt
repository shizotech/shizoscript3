
These are classes & functions which can be used with openai api compatible endpoints (v1)
TESTED WITH VLLM ONLY