
Run installer.exe as admin (Right click -> Run as Administrator)
This is only required once to associate .shio and .shx files and to add the shz.exe binary to global PATH
Happy Programming (or vibecoding lol)!

If you have shizoscript installed already, you can use update.bat to update to the newest Version.
Alternatively, open a command prompt and enter the command
shzupdate
Which does the same.